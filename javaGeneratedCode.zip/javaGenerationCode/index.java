public class Admin extends User {

	private int addminId;
	private String role;
	private String adminName;
	private int age;
	public void assignRole() {
		throw new UnsupportedOperationException();
	}

	public void viewReport() {
		throw new UnsupportedOperationException();
	}

	public void manageRestaurantData() {
		throw new UnsupportedOperationException();
	}

	public void manageUser() {
		throw new UnsupportedOperationException();
	}

	protected int getAddminId() {
		return addminId;
	}

	protected void setAddminId(int addminId) {
		this.addminId = addminId;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getAdminName() {
		return adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
}
public class Customer extends User {

	public String phoneNumber;
	public void browseRestaurant() {
		throw new UnsupportedOperationException();
	}

	public void restPassword() {
		throw new UnsupportedOperationException();
	}

	public void register() {
		throw new UnsupportedOperationException();
	}

	public void viewOrderHistory() {
		throw new UnsupportedOperationException();
	}

	public void rateFood() {
		throw new UnsupportedOperationException();
	}

	public void placeOrder() {
		throw new UnsupportedOperationException();
	}

	public void trackDelivary() {
		throw new UnsupportedOperationException();
	}
}
import java.sql.Date;
import java.sql.*;

public class Delivary {

	public int id;
	public String name;
	public Date date;
	public String address;

	public void viewDelivaryAssignments() {
		throw new UnsupportedOperationException();
	}

	public void updateDelivaryStatus() {
		throw new UnsupportedOperationException();
	}

	public void navigateToLocation() {
		throw new UnsupportedOperationException();
	}

	public void makeOrderDelivered() {
		throw new UnsupportedOperationException();
	}

	public void notifyCompletion() {
		throw new UnsupportedOperationException();
	}

	public void login() {
		throw new UnsupportedOperationException();
	}

	public void logout() {
		throw new UnsupportedOperationException();
	}
}
public class MenuItem {

	public String name;
	public double price;
	public String description;
	public int itemId;

	public void getDetails() {
		throw new UnsupportedOperationException();
	}

	public void updatePrice(double newPrice) {
		throw new UnsupportedOperationException();
	}

	public void changeDescription(String desc) {
		throw new UnsupportedOperationException();
	}

	public void toggleAvailability() {
		throw new UnsupportedOperationException();
	}
}
import java.util.*;

import org.junit.runner.manipulation.Ordering;

public class Order {

	protected int orderId;
	public String customerName;
	public List<Ordering> items;
	public Date orderTime;
	public double totalAmount;
	public int MenuItem;

	public void addItem(MenuItem item) {
		throw new UnsupportedOperationException();
	}

	public boolean removeItem(int itemId) {
		throw new UnsupportedOperationException();
	}

	public double calculateTotal() {
		throw new UnsupportedOperationException();
	}

	public String getOrderDeatils() {
		throw new UnsupportedOperationException();
	}

	public boolean isCompleted() {
		throw new UnsupportedOperationException();
	}
}
public class OrderItem {

	public int orderItemId;
	public MenuItem menuItem;
	public int quantity;
	public double price;
	public double subtotal;
	public int Menuitem;

	public double calculateSubTotal() {
		throw new UnsupportedOperationException();
	}

	public void updateQuantity(int newQuantity) {
		throw new UnsupportedOperationException();
	}

	public void getDetails() {
		throw new UnsupportedOperationException();
	}
}
import java.util.Date;

public class Payment {

	private int paymentId;
	private double amountPaid;
	private String paymentMethod;
	@SuppressWarnings("unused")
	private String paymentStatus;
	private Date paymentDate;

	public boolean makePayment(String method, double amount) {
		throw new UnsupportedOperationException();
	}

	public void getPaymentStatus() {
		throw new UnsupportedOperationException();
	}

	public boolean refund() {
		throw new UnsupportedOperationException();
	}

	public String printRecipt() {
		throw new UnsupportedOperationException();
	}

	public int getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}

	public double getAmountPaid() {
		return amountPaid;
	}

	public void setAmountPaid(double amountPaid) {
		this.amountPaid = amountPaid;
	}

	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public Date getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}
}
import java.util.Date;

public class Rating {

	public int ratingId;
	public Customer customer;
	public Restaurant restaurant;
	public Order order;
	public int score;
	public String comment;
	public Date date;

	public void submitRating() {
		throw new UnsupportedOperationException();
	}

	public void editRating(int newScore, String newComment) {
		throw new UnsupportedOperationException();
	}
}
public class Restaurant extends User {

	public String restaurantId;
	public String location;

	public void manageMenu() {
		throw new UnsupportedOperationException();
	}

	public void confirmOrder() {
		throw new UnsupportedOperationException();
	}

	public void viewOrder() {
		throw new UnsupportedOperationException();
	}

	public void updateOrderStatus() {
		throw new UnsupportedOperationException();
	}

	public void manageProfile() {
		throw new UnsupportedOperationException();
	}
}
public class RestaurantMenu {

	protected int id;
	public String name;
	public String description;
	public double price;

	public void addItem(MenuItem item) {
		throw new UnsupportedOperationException();
	}

	public void removeItem(int itemId) {
		throw new UnsupportedOperationException();
	}

	public void updateItem(MenuItem item) {
		throw new UnsupportedOperationException();
	}
}
public class User {

	public String username1;
	public String password1;

	public String email1;
	public String name1;
	public String address1;

	public String username;
	public String password;
	public String email;
	public String name;
	public String address;

	public void login1() {
		throw new UnsupportedOperationException();
	}

	public void logout1() {
		throw new UnsupportedOperationException();
	}

	public void login() {
		throw new UnsupportedOperationException();
	}

	public void logout() {
		throw new UnsupportedOperationException();
	}
}
