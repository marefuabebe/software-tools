import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AdminTest {

    @Test
    public void testSetAndGetAdminId() {
        Admin admin = new Admin();
        admin.setAddminId(101);
        assertEquals(101, admin.getAddminId());
    }

    @Test
    public void testSetAndGetRole() {
        Admin admin = new Admin();
        admin.setRole("Manager");
        assertEquals("Manager", admin.getRole());
    }

    @Test
    public void testSetAndGetAdminName() {
        Admin admin = new Admin();
        admin.setAdminName("John Doe");
        assertEquals("John Doe", admin.getAdminName());
    }

    @Test
    public void testSetAndGetAge() {
        Admin admin = new Admin();
        admin.setAge(35);
        assertEquals(35, admin.getAge());
    }

    @Test
    public void testAssignRoleThrowsException() {
        Admin admin = new Admin();
        assertThrows(UnsupportedOperationException.class, admin::assignRole);
    }

    @Test
    public void testViewReportThrowsException() {
        Admin admin = new Admin();
        assertThrows(UnsupportedOperationException.class, admin::viewReport);
    }

    @Test
    public void testManageRestaurantDataThrowsException() {
        Admin admin = new Admin();
        assertThrows(UnsupportedOperationException.class, admin::manageRestaurantData);
    }

    @Test
    public void testManageUserThrowsException() {
        Admin admin = new Admin();
        assertThrows(UnsupportedOperationException.class, admin::manageUser);
    }
}
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CustomerTest {

    @Test
    public void testBrowseRestaurantThrowsException() {
        Customer customer = new Customer();
        assertThrows(UnsupportedOperationException.class, customer::browseRestaurant);
    }

    @Test
    public void testResetPasswordThrowsException() {
        Customer customer = new Customer();
        assertThrows(UnsupportedOperationException.class, customer::restPassword);
    }

    @Test
    public void testRegisterThrowsException() {
        Customer customer = new Customer();
        assertThrows(UnsupportedOperationException.class, customer::register);
    }

    @Test
    public void testViewOrderHistoryThrowsException() {
        Customer customer = new Customer();
        assertThrows(UnsupportedOperationException.class, customer::viewOrderHistory);
    }

    @Test
    public void testRateFoodThrowsException() {
        Customer customer = new Customer();
        assertThrows(UnsupportedOperationException.class, customer::rateFood);
    }

    @Test
    public void testPlaceOrderThrowsException() {
        Customer customer = new Customer();
        assertThrows(UnsupportedOperationException.class, customer::placeOrder);
    }

    @Test
    public void testTrackDeliveryThrowsException() {
        Customer customer = new Customer();
        assertThrows(UnsupportedOperationException.class, customer::trackDelivary);
    }

    @Test
    public void testPhoneNumberAssignment() {
        Customer customer = new Customer();
        customer.phoneNumber = "123-456-7890";
        assertEquals("123-456-7890", customer.phoneNumber);
    }
}
import org.junit.jupiter.api.Test;
import java.sql.Date;

import static org.junit.jupiter.api.Assertions.*;

public class DelivaryTest {

    @Test
    public void testViewDelivaryAssignmentsThrowsException() {
        Delivary d = new Delivary();
        assertThrows(UnsupportedOperationException.class, d::viewDelivaryAssignments);
    }

    @Test
    public void testUpdateDelivaryStatusThrowsException() {
        Delivary d = new Delivary();
        assertThrows(UnsupportedOperationException.class, d::updateDelivaryStatus);
    }

    @Test
    public void testNavigateToLocationThrowsException() {
        Delivary d = new Delivary();
        assertThrows(UnsupportedOperationException.class, d::navigateToLocation);
    }

    @Test
    public void testMakeOrderDeliveredThrowsException() {
        Delivary d = new Delivary();
        assertThrows(UnsupportedOperationException.class, d::makeOrderDelivered);
    }

    @Test
    public void testNotifyCompletionThrowsException() {
        Delivary d = new Delivary();
        assertThrows(UnsupportedOperationException.class, d::notifyCompletion);
    }

    @Test
    public void testLoginThrowsException() {
        Delivary d = new Delivary();
        assertThrows(UnsupportedOperationException.class, d::login);
    }

    @Test
    public void testLogoutThrowsException() {
        Delivary d = new Delivary();
        assertThrows(UnsupportedOperationException.class, d::logout);
    }

    @Test
    public void testAttributesAssignment() {
        Delivary d = new Delivary();
        d.id = 1;
        d.name = "John Doe";
        d.date = Date.valueOf("2025-01-01");
        d.address = "123 Street";

        assertEquals(1, d.id);
        assertEquals("John Doe", d.name);
        assertEquals(Date.valueOf("2025-01-01"), d.date);
        assertEquals("123 Street", d.address);
    }
}
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MenuItemTest {

    @Test
    public void testGetDetailsThrowsException() {
        MenuItem item = new MenuItem();
        assertThrows(UnsupportedOperationException.class, item::getDetails);
    }

    @Test
    public void testUpdatePriceThrowsException() {
        MenuItem item = new MenuItem();
        assertThrows(UnsupportedOperationException.class, () -> item.updatePrice(12.99));
    }

    @Test
    public void testChangeDescriptionThrowsException() {
        MenuItem item = new MenuItem();
        assertThrows(UnsupportedOperationException.class, () -> item.changeDescription("New description"));
    }

    @Test
    public void testToggleAvailabilityThrowsException() {
        MenuItem item = new MenuItem();
        assertThrows(UnsupportedOperationException.class, item::toggleAvailability);
    }

    @Test
    public void testAttributeAssignment() {
        MenuItem item = new MenuItem();
        item.name = "Pizza";
        item.price = 8.99;
        item.description = "Cheesy pizza with toppings";
        item.itemId = 101;

        assertEquals("Pizza", item.name);
        assertEquals(8.99, item.price);
        assertEquals("Cheesy pizza with toppings", item.description);
        assertEquals(101, item.itemId);
    }
}
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class OrderItemTest {

    @Test
    public void testCalculateSubTotalThrowsException() {
        OrderItem item = new OrderItem();
        assertThrows(UnsupportedOperationException.class, item::calculateSubTotal);
    }

    @Test
    public void testUpdateQuantityThrowsException() {
        OrderItem item = new OrderItem();
        assertThrows(UnsupportedOperationException.class, () -> item.updateQuantity(3));
    }

    @Test
    public void testGetDetailsThrowsException() {
        OrderItem item = new OrderItem();
        assertThrows(UnsupportedOperationException.class, item::getDetails);
    }

    @Test
    public void testAttributeAssignment() {
        OrderItem item = new OrderItem();
        MenuItem menu = new MenuItem();
        menu.name = "Burger";
        menu.price = 5.50;

        item.orderItemId = 1;
        item.menuItem = menu;
        item.quantity = 2;
        item.price = 5.50;
        item.subtotal = 11.00;

        assertEquals(1, item.orderItemId);
        assertEquals(menu, item.menuItem);
        assertEquals("Burger", item.menuItem.name);
        assertEquals(2, item.quantity);
        assertEquals(5.50, item.price);
        assertEquals(11.00, item.subtotal);
    }
}
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

public class OrderTest {

    private Order order;

    @BeforeEach
    public void setUp() {
        order = new Order();
        order.customerName = "John Doe";
        order.orderTime = new Date();
        order.totalAmount = 0.0;
    }

    @Test
    public void testAddItemThrowsException() {
        MenuItem dummyItem = new MenuItem(); // assuming MenuItem has a default constructor
        assertThrows(UnsupportedOperationException.class, () -> {
            order.addItem(dummyItem);
        });
    }

    @Test
    public void testRemoveItemThrowsException() {
        assertThrows(UnsupportedOperationException.class, () -> {
            order.removeItem(1);
        });
    }

    @Test
    public void testCalculateTotalThrowsException() {
        assertThrows(UnsupportedOperationException.class, () -> {
            order.calculateTotal();
        });
    }

    @Test
    public void testGetOrderDetailsThrowsException() {
        assertThrows(UnsupportedOperationException.class, () -> {
            order.getOrderDeatils();
        });
    }

    @Test
    public void testIsCompletedThrowsException() {
        assertThrows(UnsupportedOperationException.class, () -> {
            order.isCompleted();
        });
    }
}
import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

public class PaymentTest {

    @Test
    public void testMakePaymentThrowsException() {
        Payment payment = new Payment();
        assertThrows(UnsupportedOperationException.class, () -> payment.makePayment("Credit Card", 100.0));
    }

    @Test
    public void testGetPaymentStatusThrowsException() {
        Payment payment = new Payment();
        assertThrows(UnsupportedOperationException.class, payment::getPaymentStatus);
    }

    @Test
    public void testRefundThrowsException() {
        Payment payment = new Payment();
        assertThrows(UnsupportedOperationException.class, payment::refund);
    }

    @Test
    public void testPrintReciptThrowsException() {
        Payment payment = new Payment();
        assertThrows(UnsupportedOperationException.class, payment::printRecipt);
    }

    @Test
    public void testGettersAndSetters() {
        Payment payment = new Payment();

        int expectedId = 101;
        double expectedAmount = 75.25;
        String expectedMethod = "Debit Card";
        String expectedStatus = "Completed";
        Date expectedDate = new Date();

        payment.setPaymentId(expectedId);
        payment.setAmountPaid(expectedAmount);
        payment.setPaymentMethod(expectedMethod);
        payment.setPaymentStatus(expectedStatus);  // No getter available
        payment.setPaymentDate(expectedDate);

        assertEquals(expectedId, payment.getPaymentId());
        assertEquals(expectedAmount, payment.getAmountPaid());
        assertEquals(expectedMethod, payment.getPaymentMethod());
        assertEquals(expectedDate, payment.getPaymentDate());
    }
}
import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

public class RatingTest {

    @Test
    public void testSubmitRatingThrowsException() {
        Rating rating = new Rating();
        assertThrows(UnsupportedOperationException.class, rating::submitRating);
    }

    @Test
    public void testEditRatingThrowsException() {
        Rating rating = new Rating();
        assertThrows(UnsupportedOperationException.class, () -> rating.editRating(4, "Great experience!"));
    }

    @Test
    public void testAttributeAssignment() {
        Rating rating = new Rating();
        Customer customer = new Customer();
        Restaurant restaurant = new Restaurant();
        Order order = new Order();
        Date now = new Date();

        rating.ratingId = 1;
        rating.customer = customer;
        rating.restaurant = restaurant;
        rating.order = order;
        rating.score = 5;
        rating.comment = "Excellent!";
        rating.date = now;

        assertEquals(1, rating.ratingId);
        assertEquals(customer, rating.customer);
        assertEquals(restaurant, rating.restaurant);
        assertEquals(order, rating.order);
        assertEquals(5, rating.score);
        assertEquals("Excellent!", rating.comment);
        assertEquals(now, rating.date);
    }
}
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RestaurantMenuTest {

    private RestaurantMenu restaurantMenu;
    private MenuItem sampleItem;

    @BeforeEach
    public void setUp() {
        restaurantMenu = new RestaurantMenu();
        sampleItem = new MenuItem(); // Assuming MenuItem has a no-arg constructor
    }

    @Test
    public void testAddItemThrowsException() {
        assertThrows(UnsupportedOperationException.class, () -> {
            restaurantMenu.addItem(sampleItem);
        });
    }

    @Test
    public void testRemoveItemThrowsException() {
        assertThrows(UnsupportedOperationException.class, () -> {
            restaurantMenu.removeItem(1);
        });
    }

    @Test
    public void testUpdateItemThrowsException() {
        assertThrows(UnsupportedOperationException.class, () -> {
            restaurantMenu.updateItem(sampleItem);
        });
    }
}
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RestaurantTest {

    @Test
    public void testManageMenuThrowsException() {
        Restaurant restaurant = new Restaurant();
        assertThrows(UnsupportedOperationException.class, restaurant::manageMenu);
    }

    @Test
    public void testConfirmOrderThrowsException() {
        Restaurant restaurant = new Restaurant();
        assertThrows(UnsupportedOperationException.class, restaurant::confirmOrder);
    }

    @Test
    public void testViewOrderThrowsException() {
        Restaurant restaurant = new Restaurant();
        assertThrows(UnsupportedOperationException.class, restaurant::viewOrder);
    }

    @Test
    public void testUpdateOrderStatusThrowsException() {
        Restaurant restaurant = new Restaurant();
        assertThrows(UnsupportedOperationException.class, restaurant::updateOrderStatus);
    }

    @Test
    public void testManageProfileThrowsException() {
        Restaurant restaurant = new Restaurant();
        assertThrows(UnsupportedOperationException.class, restaurant::manageProfile);
    }

    @Test
    public void testAttributeAssignment() {
        Restaurant restaurant = new Restaurant();
        restaurant.restaurantId = "REST101";
        restaurant.location = "Downtown";

        assertEquals("REST101", restaurant.restaurantId);
        assertEquals("Downtown", restaurant.location);
    }
}
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class UserTest {

    private User user;

    @BeforeEach
    public void setUp() {
        user = new User();
    }

    @Test
    public void testLoginThrowsException() {
        assertThrows(UnsupportedOperationException.class, () -> {
            user.login();
        });
    }

    @Test
    public void testLogoutThrowsException() {
        assertThrows(UnsupportedOperationException.class, () -> {
            user.logout();
        });
    }

    @Test
    public void testLogin1ThrowsException() {
        assertThrows(UnsupportedOperationException.class, () -> {
            user.login1();
        });
    }

    @Test
    public void testLogout1ThrowsException() {
        assertThrows(UnsupportedOperationException.class, () -> {
            user.logout1();
        });
    }
}
